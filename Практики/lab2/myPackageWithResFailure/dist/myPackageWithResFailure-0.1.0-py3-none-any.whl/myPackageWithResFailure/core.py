import numpy as np

array = np.arrange(10)

print(array)